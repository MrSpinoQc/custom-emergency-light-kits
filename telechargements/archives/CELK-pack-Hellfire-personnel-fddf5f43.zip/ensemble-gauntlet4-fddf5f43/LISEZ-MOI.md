# Ensemble FiveM · gauntlet4

Runtime requis · CELK 0.2.0-rc.2-hellfire.3. Le modèle gauntlet4 doit être disponible en jeu.

1. Lis les identités et versions dans `installation.json`. L’administrateur déclare et démarre les ressources jointes, en fusionnant leur configuration avec celle du serveur. En cas de collision ou de version différente, traiter le conflit avant l’installation.
2. Place l’ensemble entier dans `celk_runtime/local/install-sets`. Garde les noms de dossiers et les empreintes.
3. Dans la console, utilise `celk_preflight_set <dossier>`. Vérifie le résultat et relève le SHA du plan.
4. Utilise `celk_install_set <dossier> <SHA-du-plan>`, puis effectue le rechargement planifié selon la notice du runtime.

Une variante identique peut être rejouée. Un même identifiant avec un contenu différent demande de résoudre le conflit. Le service Mécano est une catégorie de montage dans F6.
