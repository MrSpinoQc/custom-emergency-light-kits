# Mises à jour et retour arrière

Le script et le pack s’installent manuellement. Le dossier `celk_runtime/local` est le dossier de données du serveur. Planifie une sauvegarde avant remplacement de fichiers, activation ou migration. Conserve une copie de tout le dossier `local` ainsi que les anciens ZIP et leur manifeste. Le fichier exemple reste distinct de la configuration locale.

## Installer une révision model

1. Conserve les livraisons et les dossiers scellés. Dans `local/models/<modèle>/<dossier>`, ajoute la nouvelle livraison complète et ses montages référencés. Le numéro est un entier, comparé dans la provenance configurée. Par exemple, `10` succède à `9`. Deux fichiers de révision égale et de contenus différents entraînent un refus. Des copies octet pour octet du même manifeste et des montages sont reconnues comme identiques.
2. Lance `celk_preflight`, relis les rapports, puis `celk_activate` au créneau d’entretien. Une première activation écrit un index après validation complète. L’index référence des copies scellées par empreinte, hors du dossier de livraisons candidates.
3. Redémarre `celk_runtime`. Le moteur recharge l’index validé. Si la version d’un pack de fichiers change, le script doit disposer de son lecteur et de cette version, puis le pack et le script doivent être redémarrés dans cet ordre.
4. Après démarrage, contrôle la révision avec `celk_status`. Relie les véhicules selon leur identité durable. Un renommage compatible garde l’ID et les pièces. Une variante retirée ou un contenu modifié reçoit un diagnostic. Pour une réassignation explicitement décidée, sauvegarde d’abord `local`, ouvre `celk_bind <identifiant-durable> reassign` au volant, puis choisis la variante dans F6. Le fichier n’est modifié qu’au choix validé.

Le script `0.1.1` lit aussi le `livraison.json` écrit par le bouton Atelier avec son dossier `montages`. Il relie la référence Studio vérifiée `phantom-fantome@0.1.0-candidat.1` au pack runtime `phantom-grand-format@0.1.0`. Place le dossier de l’export complet sous `local/models/phantom`. Le montage de démonstration inclus dans le pack et une livraison Atelier sont deux contenus distincts. Si l’exemple est déjà activé en révision 1, exporte depuis l’Atelier avec une révision supérieure pour remplacer ce modèle. Garde les fichiers de travail et l’export auteur dans les dossiers privés.

## Revenir en arrière

Dans la console serveur, `celk_preflight <modèle> <révision> <empreinte-minuscule>` vérifie une livraison précise. Utilise les mêmes arguments avec `celk_activate`. Redémarre `celk_runtime` après résultat positif. Cette sélection résiste au dépôt d’une révision supérieure. Une nouvelle activation sans épingle constitue une décision explicite de revenir à la résolution par révision maximale.

En cas de changement de script, garde `local` séparé lors du remplacement de la ressource. Si un ancien script ne peut plus lire l’état, arrête la ressource au créneau d’entretien et restaure ensemble la copie du script, du pack et la sauvegarde `local` qui leur correspond. Préserve la sauvegarde actuelle pour examiner ensuite les écritures plus récentes. Vérifie `celk_status` avant de relier les véhicules.

Une interruption peut laisser `.model-activation.lock` ou un dossier de préparation temporaire. Avant de retirer un verrou périmé, vérifie que le processus d’activation correspondant est arrêté. L’index déjà écrit reste lisible. Conserve les dossiers scellés pour l’audit et la reprise.

## Migration du montage historique

Le nouveau fichier `installed-mounts.json` a son propre schéma v1 avec un ID par véhicule. Un montage historique v1 de la famille `phantom-police-atelier-4` peut être repris sur un même ID avec un mappage explicite et lorsque les pièces sauvegardées correspondent exactement aux descripteurs de la variante active. Un ancien export mono-montage est enveloppé manuellement en suivant `Modele-Phantom`. Les données source conservent leurs octets.

Prépare des copies dans `local/migration/legacy-v1.json` et `local/migration/mapping.json`. Le mappage d’un véhicule est de la forme suivante.

```json
{
  "vehicleId": "vehicule-a",
  "model": "phantom",
  "service": "police",
  "preset": "phantom-police-atelier-4",
  "variantId": "phantom-police-atelier-4"
}
```

Exécute `celk_migrate vehicule-a` en console. La commande refuse un ID déjà présent, un état inconnu, un autre modèle ou des descripteurs divergents. L’état d’origine demeure disponible pour une migration ultérieure. Les adaptations Qbox du labo et les options d’autres packs demandent leur propre migration.
