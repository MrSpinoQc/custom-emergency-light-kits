local driving = {
    police = { service = 'police', grade = 0 },
    ambulance = { service = 'ambulance', grade = 0 },
    mechanic = { service = 'mecano', grade = 0 },
}

function CelkQboxAllows(job, action, service, owned)
    if owned ~= true or not job or job.onduty ~= true then return false end
    local rule = driving[job.name]
    local grade = job.grade and job.grade.level
    if not rule or type(grade) ~= 'number' or grade < rule.grade then return false end
    if action == 'bind' then return true end
    if action == 'fit' then return job.name == 'mechanic' and grade >= 1 end
    if action == 'drive' then return rule.service == service end
    return false
end
