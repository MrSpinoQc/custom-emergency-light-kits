'use strict';

const { move, position } = require('./sadler-behavior.cjs');

function create(durationMs, modes, defaultMode) {
    return { travel: { raiseMs: durationMs, lowerMs: durationMs }, modes, mode: defaultMode,
        motion: { from: 0, to: 0, startedAt: 0, duration: 0 }, armed: false, paused: false };
}

function moveTo(state, to, now) {
    if (state.motion.to === to) return false;
    state.motion = move(state, state, to, now).motion;
    state.armed = false;
    state.paused = false;
    state.signalAt = undefined;
    return true;
}

function command(state, name, now, source) {
    if (typeof name !== 'string' || !Number.isFinite(now)) return false;
    if (name === 'open' || name === 'close') {
        if (!moveTo(state, Number(name === 'open'), now)) return false;
    } else if (name.startsWith('mode:')) {
        const mode = name.slice(5);
        if (!state.modes.has(mode) || state.mode === mode) return false;
        state.mode = mode;
        if (state.armed && !state.paused) state.signalAt = now;
    } else if (name === 'signal:on') {
        if (state.armed || state.motion.to !== 1 || position(state.motion, now) !== 1) return false;
        state.armed = true;
        state.signalAt = now;
    } else if (name === 'signal:off') {
        if (!state.armed) return false;
        state.armed = false;
        state.paused = false;
        state.signalAt = undefined;
    } else if (name === 'pause:on' || name === 'pause:off') {
        const pause = name === 'pause:on';
        if (!state.armed || state.paused === pause) return false;
        state.paused = pause;
        state.signalAt = pause ? undefined : now;
    } else return false;
    state.operator = source;
    return true;
}

function stop(state, now) {
    const changed = moveTo(state, 0, now);
    state.operator = undefined;
    return changed;
}

function snapshot(state, now) {
    const { motion, mode, armed, paused, signalAt } = state;
    return { position: position(motion, now), target: motion.to,
        remainingMs: Math.max(0, motion.startedAt + motion.duration - now), mode, armed, paused,
        signalElapsedMs: signalAt === undefined ? 0 : Math.max(0, now - signalAt) };
}

function installed(parts = []) {
    const panels = new Map();
    for (const part of parts) {
        const def = part.auxPanel;
        if (!def) continue;
        const duration = def.pivots.reduce((ms, pivot) => ms + pivot.durationMs, 0);
        const state = create(duration, new Map(def.modes.map(mode => [mode.id, mode.label])), def.defaultMode);
        panels.set(part.id, { def, state });
    }
    return panels;
}

function operate(panels, value, now, source) {
    if (typeof value !== 'string' || !panels) return false;
    const split = value.indexOf('/');
    if (split < 1) return false;
    const panel = panels.get(value.slice(0, split));
    if (!panel || (panel.state.operator && panel.state.operator !== source)) return false;
    return command(panel.state, value.slice(split + 1), now, source);
}

// The service clock and the panel clock travel separately. Only controls offered by
// the fitted panel are exposed, with the mount key disambiguating shared mode IDs.
function options(panels, now) {
    return Array.from(panels, ([pieceId, {def,state}]) => {
        const pose = snapshot(state, now);
        const item = (key, label, on, disabled = false) => ({ id: pieceId + '/' + key, key, label, on, disabled });
        return { pieceId, definition: def, pose,
            controls: [item('open', 'Déployer', pose.target === 1), item('close', 'Replier', pose.target === 0),
                ...def.modes.map(mode => item('mode:' + mode.id, mode.label, pose.mode === mode.id)),
                item(state.armed ? 'signal:off' : 'signal:on', state.armed ? 'Couper' : 'Armer', state.armed, !pose.target),
                item(state.paused ? 'pause:off' : 'pause:on', state.paused ? 'Reprendre' : 'Pause', state.paused, !state.armed)] };
    });
}

module.exports = { create, command, stop, snapshot, installed, operate, options };
