# Custom Emergency Light Kits · Phantom Grand Format

**Spino** · Pack d’accessoires Phantom Grand Format **0.1.0** · Service Police.

- Installe `celk_pack_phantom` avant `celk_runtime`. La paire de ce lot a été vérifiée avec **celk_runtime 0.1.2**. Suis le guide `INSTALLATION.md` fourni avec le script 0.1.2.
- Le dossier `Modele-Phantom` fournit un exemple à 14 accessoires et cinq scènes, service Police. Son `model-export.json` associe le montage à l’identifiant `phantom`. Les optiques se fixent sur le Phantom GTA de ton installation.
- Le pack fournit quatre modèles d’optiques de Spino, leurs lentilles rouge et bleue, la géométrie des pièces et les réglages lumineux du montage. Les fichiers de carrosserie, de textures et de modèle du camion proviennent de ton installation GTA et sont hors de cette archive.

Le crédit d’auteur est **Spino**. Les conditions de redistribution seront précisées avant la diffusion.
