local runtime = 'celk_runtime'
local framework = 'qbx_core'
local vehicles = 'qbx_vehicles'
local garage = 'qbx_garages'
local ready, pending = {}, {}
local hookReady = false

local function normalizePlate(value)
    if type(value) ~= 'string' then return end
    local plate = value:match('^%s*(.-)%s*$'):upper()
    if #plate > 0 and #plate <= 8 then return plate end
end

local function live(entry)
    return DoesEntityExist(entry.entity) and GetEntityType(entry.entity) == 2
        and NetworkGetNetworkIdFromEntity(entry.entity) == entry.netId
        and NetworkGetEntityFromNetworkId(entry.netId) == entry.entity
        and GetEntityRoutingBucket(entry.entity) == entry.bucket
        and GetEntityModel(entry.entity) == entry.modelHash
        and Entity(entry.entity).state.vehicleid == entry.id
        and normalizePlate(GetVehicleNumberPlateText(entry.entity)) == entry.plate
end

local function restore(entry)
    if GetResourceState(runtime) == 'started' and ready[entry.id] == entry and live(entry) then
        exports[runtime]:RestoreGarageMount(entry.id, entry.entity, entry.netId)
    end
end

-- The stock 1.1.4 garage emits only the entity, after writing its durable ID and saving OUT.
AddEventHandler('qbx_garages:server:vehicleSpawned', function(entity)
    if GetInvokingResource() ~= garage or not hookReady or type(entity) ~= 'number' or entity < 1
        or not DoesEntityExist(entity) or GetEntityType(entity) ~= 2 then return end
    local id = Entity(entity).state.vehicleid
    local netId = NetworkGetNetworkIdFromEntity(entity)
    local plate = normalizePlate(GetVehicleNumberPlateText(entity))
    if type(id) ~= 'number' or id % 1 ~= 0 or id < 1 or id > 2147483647
        or not netId or netId < 1 or netId > 65535 or not plate then return end
    if ready[id] and live(ready[id]) then return end
    local entry = { id = id, entity = entity, netId = netId, plate = plate,
        bucket = GetEntityRoutingBucket(entity), modelHash = GetEntityModel(entity) }
    pending[id] = entry
    local row = exports[vehicles]:GetPlayerVehicle(id, { states = 0 })
    if pending[id] ~= entry then return end
    pending[id] = nil
    if not row or row.id ~= id or row.state ~= 0 or type(row.modelName) ~= 'string'
        or type(row.citizenid) ~= 'string' or row.citizenid == ''
        or joaat(row.modelName) % 4294967296 ~= entry.modelHash % 4294967296
        or not row.props or normalizePlate(row.props.plate) ~= plate
        or not live(entry) then return end
    entry.model, entry.owner = row.modelName, row.citizenid
    ready[id] = entry
    SetTimeout(0, function() restore(entry) end)
end)

AddEventHandler('entityRemoved', function(entity)
    for id, entry in pairs(ready) do
        if entry.entity == entity then ready[id] = nil end
    end
    for id, entry in pairs(pending) do
        if entry.entity == entity then pending[id] = nil end
    end
end)

local function registerOwnerHook()
    local id = exports[vehicles]:registerHook('changeVehicleOwner', function(change)
        local vehicleId = change.vehicleId
        if type(vehicleId) == 'number' then ready[vehicleId], pending[vehicleId] = nil, nil end
    end)
    hookReady = type(id) == 'number'
end

CreateThread(registerOwnerHook)
AddEventHandler('onResourceStart', function(resource)
    if resource == vehicles then SetTimeout(0, registerOwnerHook) end
    if resource ~= runtime then return end
    SetTimeout(0, function()
        for _, entry in pairs(ready) do restore(entry) end
    end)
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == vehicles then hookReady = false end
    if resource == vehicles or resource == garage or resource == framework then
        ready, pending = {}, {}
    end
end)

exports('Authorize', function(source, action, service, target, durable)
    if GetInvokingResource() ~= runtime or not hookReady or type(target) ~= 'table' then return false end
    local id = type(durable) == 'string' and tonumber(durable:match('^qbx%-([1-9]%d*)$'))
    local entry = id and ready[id]
    if not entry or entry.entity ~= target.entity or entry.netId ~= target.netId or entry.model ~= target.model
        or not live(entry) then return false end
    local player = exports[framework]:GetPlayer(source)
    local data = player and player.PlayerData
    if not data or data.citizenid ~= entry.owner then return false end
    return CelkQboxAllows(data.job, action, service, true)
end)
