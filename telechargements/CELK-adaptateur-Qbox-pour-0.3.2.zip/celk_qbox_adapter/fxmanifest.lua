fx_version 'cerulean'
game 'gta5'
author 'Spino'
version '0.3.3'
description 'CELK Qbox server integration'
server_only 'yes'
dependencies { 'qbx_core', 'qbx_vehicles', 'qbx_garages', '/onesync' }
server_scripts { 'policy.lua', 'server.lua' }
