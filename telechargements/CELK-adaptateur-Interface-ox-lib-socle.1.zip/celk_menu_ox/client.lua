local context = 'celk_vehicle_interface'
local opened
local displayed

local function hide()
    opened, displayed = nil, nil
    if lib.getOpenContextMenu() == context then lib.hideContext(false) end
end

exports('ShowCELKMenu', function(session, view)
    if GetInvokingResource() ~= 'celk_runtime' or view.apiVersion ~= 1 then return false end
    local options = {}
    local delayed = {}
    local function add(item, action, description, disabled)
        options[#options + 1] = {
            title = item.label,
            description = description,
            disabled = disabled == true,
            onSelect = function()
                if opened ~= session then return end
                if not exports.celk_runtime:SubmitCELKMenuAction(session, action, item.id) then
                    exports.celk_runtime:DismissCELKMenu(session)
                end
            end,
        }
    end
    if view.notice then
        options[#options + 1] = { title = view.notice, readOnly = true }
    end
    local fitting = view.pane == 'variants'
    if not fitting then
        options[#options + 1] = { title = 'Variantes de lumière', readOnly = true,
            description = #view.choices == 0 and 'Aucune variante de lumière dans ce montage.' or nil }
    end
    for _, item in ipairs(view.choices) do
        local selected = item.id == view.selected
        add(item, fitting and 'variant' or 'scene',
            selected and (fitting and 'Installé' or 'Sélectionnée') or nil, fitting and selected)
    end
    if not fitting then
        for _ = #view.choices + 1, 5 do
            options[#options + 1] = { title = '—', description = 'Emplacement libre', readOnly = true }
        end
        if type(view.scenePlayback) == 'table' and type(view.scenePlayback.on) == 'boolean' then
            local playing = view.scenePlayback.on
            add({ id = playing and 'off' or 'on', label = playing and 'Arrêter la scène' or 'Lire la scène' },
                'scenePlayback')
        end
    end
    if not fitting and (#(view.rampControls or {}) > 0 or #(view.auxPanels or {}) > 0 or #(view.projectors or {}) > 0) then
        options[#options + 1] = { title = 'Auxiliaires', readOnly = true }
    end
    for _, item in ipairs(view.rampControls or {}) do
        if item.id ~= 'linkedCorners' and item.id ~= 'independentCorners'
            and not (item.on and (item.id == 'open' or item.id == 'close')) then
            local motion = view.rampMotion
            local waiting = item.id == 'signal:on' and motion and motion.kind == 'trifold'
                and motion.target == 1 and motion.remainingMs > 0
            add(item, 'sadler', waiting and 'Disponible en fin de déploiement' or (item.on and 'Actif' or nil),
                item.disabled or waiting)
            if waiting then delayed[#delayed + 1] = { option = options[#options], ms = motion.remainingMs } end
        end
    end
    for _, panel in ipairs(view.auxPanels or {}) do
        options[#options + 1] = { title = panel.definition.label, readOnly = true }
        for _, item in ipairs(panel.controls) do
            local move = item.key == 'open' or item.key == 'close'
            if not (move and item.on) then
                local waiting = item.key == 'signal:on' and panel.pose.target == 1 and panel.pose.remainingMs > 0
                add(item, 'auxPanel', waiting and 'Disponible en fin de déploiement' or (item.on and 'Actif' or nil),
                    item.disabled or waiting)
                if waiting then delayed[#delayed + 1] = { option = options[#options], ms = panel.pose.remainingMs } end
            end
        end
    end
    for _, item in ipairs(view.projectors or {}) do
        local state = item.on and 'Allumé' or 'Éteint'
        add(item, 'projector', state)
        if item.aimable then
            add({ id = item.id, label = 'Viser · ' .. item.label }, 'projectorAim',
                ('%s° / %s° · Pavé 4/6/8/2'):format(item.yaw, item.pitch))
        end
    end
    if #options == 0 then return false end
    opened = session
    local page = {
        id = context,
        title = fitting and 'Montages CELK' or (view.mountLabel or 'Commandes d’éclairage'),
        onExit = function()
            if opened ~= session then return end
            opened, displayed = nil, nil
            exports.celk_runtime:DismissCELKMenu(session)
        end,
        options = options,
    }
    displayed = page
    lib.registerContext(page)
    lib.showContext(context)
    for _, delay in ipairs(delayed) do
        SetTimeout(math.ceil(delay.ms), function()
            if displayed ~= page or opened ~= session or lib.getOpenContextMenu() ~= context then return end
            delay.option.disabled, delay.option.description = false, nil
            lib.registerContext(page)
            lib.showContext(context)
        end)
    end
    return true
end)

exports('HideCELKMenu', function(session)
    if GetInvokingResource() == 'celk_runtime' and opened == session then hide() end
end)

AddEventHandler('onClientResourceStop', function(name)
    if name == GetCurrentResourceName() and opened and GetResourceState('ox_lib') == 'started' then hide() end
end)
