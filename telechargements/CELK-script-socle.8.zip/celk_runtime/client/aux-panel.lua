-- Client interpreter for the pack's versioned auxiliary panel. Body/point
-- offsets are local GTA metres; pivot angles are single-axis parent-local degrees.
local M = { renderer = 'celk-auxiliary-panel-v1' }
local zero = { x = 0, y = 0, z = 0 }
local clockRange = 4294967296

local function stable(value)
    return type(value) == 'string' and #value > 0 and #value <= 64
        and value:match('^[A-Za-z0-9][A-Za-z0-9_.%-]*$') ~= nil
end

local function model(value)
    return type(value) == 'string' and #value <= 63 and value:match('^[a-z][a-z0-9_]*$') ~= nil
end

local function xyz(offset) return { x = offset[1], y = offset[2], z = offset[3] } end

local function plan(def, v)
    if type(def) ~= 'table' or def.schema ~= 'celk.auxiliary-panel' or def.version ~= 1
        or not stable(def.id) or not model(def.authoringModel) or not stable(def.pieceKey)
        or not v.dense(def.requires, 2, 2) or not v.dense(def.bodies, 2, 8)
        or not v.dense(def.pivots, #def.bodies - 1, #def.bodies - 1)
        or not v.dense(def.points, 1, 32) or not v.dense(def.groups, 1, 16)
        or not v.dense(def.modes, 1, 5) then return end
    local caps = {}
    for _, c in ipairs(def.requires) do
        if c ~= 'rigid-sequence-v1' and c ~= 'emissive-groups-v1' then return end
        caps[c] = true
    end
    if not caps['rigid-sequence-v1'] or not caps['emissive-groups-v1'] then return end
    local bodies, points, groups, modes = {}, {}, {}, {}
    for _, body in ipairs(def.bodies) do
        if type(body) ~= 'table' or not stable(body.id) or bodies[body.id] or not model(body.model) then return end
        bodies[body.id] = body.model
    end
    local rootId = def.bodies[1].id
    local ready = { [rootId] = true }
    local order = {{ id = rootId, model = bodies[rootId] }}
    local duration = 0
    for _, p in ipairs(def.pivots) do
        if type(p) ~= 'table' or not bodies[p.body] or ready[p.body] or not ready[p.parent]
            or (p.axis ~= 'x' and p.axis ~= 'y' and p.axis ~= 'z')
            or not v.triple(p.offset, 10) or not v.bounded(p.closedDeg, -180, 180)
            or not v.bounded(p.openDeg, -180, 180) or p.closedDeg == p.openDeg
            or not v.integer(p.durationMs, 50, 10000) then return end
        order[#order + 1] = { id = p.body, parent = p.parent, model = bodies[p.body], offset = xyz(p.offset),
            axis = p.axis, closed = p.closedDeg, open = p.openDeg, start = duration, duration = p.durationMs }
        ready[p.body] = true
        duration = duration + p.durationMs
    end
    if duration > 30000 then return end
    local channels = {}
    for _, p in ipairs(def.points) do
        if type(p) ~= 'table' or not stable(p.id) or points[p.id] or not ready[p.body] or not model(p.model)
            or not v.triple(p.offset, 10) then return end
        points[p.id] = true
        channels[#channels+1] = { id = p.id, parent = p.body, model = p.model, offset = xyz(p.offset) }
    end
    for _, g in ipairs(def.groups) do
        if type(g) ~= 'table' or not stable(g.id) or groups[g.id] or not v.dense(g.points, 1, #channels) then return end
        local members = {}
        for _, id in ipairs(g.points) do
            if not points[id] or members[id] then return end
            members[id] = true
        end
        groups[g.id] = members
    end
    for _, m in ipairs(def.modes) do
        if type(m) ~= 'table' or not stable(m.id) or modes[m.id] or not v.dense(m.steps, 1, 32) then return end
        local steps, period = {}, 0
        for _, s in ipairs(m.steps) do
            if type(s) ~= 'table' or not v.integer(s.durationMs, 50, 10000) or not v.dense(s.groups, 0, #def.groups) then return end
            local active, seen = {}, {}
            for _, id in ipairs(s.groups) do
                if not groups[id] or seen[id] then return end
                seen[id] = true
                for point in pairs(groups[id]) do active[point] = true end
            end
            period = period + s.durationMs
            steps[#steps + 1] = { untilMs = period, points = active }
        end
        if period > 30000 then return end
        modes[m.id] = { steps = steps, period = period }
    end
    if not modes[def.defaultMode] then return end
    return { duration = duration, bodies = order, points = channels, modes = modes }
end

function M.validate(raw, pose, v, now)
    local def, digest = raw.auxPanel, raw.auxPanelDigest
    if type(def) ~= 'table' or raw.id ~= def.pieceKey or raw.model ~= def.authoringModel
        or raw.kind ~= 'celk-optics-v1'
        or type(digest) ~= 'string' or #digest ~= 64 or not digest:match('^[0-9a-f]+$')
        or not v.vec(raw.position, 12) or not v.vec(raw.rotation, 180)
        or not v.dense(raw.optics, 0, 0) or raw.original ~= nil
        or raw.projector ~= nil or raw.trifold ~= nil or raw.bone ~= nil then return end
    local rig = plan(def, v)
    if not rig or type(pose) ~= 'table' or not rig.modes[pose.mode]
        or not v.bounded(pose.position, 0, 1) or (pose.target ~= 0 and pose.target ~= 1)
        or not v.bounded(pose.remainingMs, 0, rig.duration) or not v.bounded(pose.signalElapsedMs, 0, 9007199254740991)
        or type(pose.armed) ~= 'boolean' or type(pose.paused) ~= 'boolean' then return end
    local remaining = math.abs(pose.target - pose.position) * rig.duration
    if math.abs(remaining - pose.remainingMs) > 1 or (pose.paused and not pose.armed)
        or (pose.armed and (pose.position ~= 1 or pose.target ~= 1 or pose.remainingMs ~= 0)) then return end
    return { id = raw.id, model = raw.model, position = raw.position, rotation = raw.rotation,
        kind = M.renderer, geometry = digest, rig = rig, pose = pose, receivedAt = now, registry = {}, palette = {} }
end

local function hide(slot, native)
    native.release(slot)
    if native.valid(slot) then native.lens(slot, slot.object, 0) end
end

local function place(state, slot, parent, node, pos, angle, fixedRotation, now, native, visible)
    if not parent then hide(slot, native); return end
    local object
    if native.valid(slot) then
        object = slot.object
    elseif state.opticsAllocationBudget > 0 and (not slot.retry or now >= slot.retry) then
        state.opticsAllocationBudget = state.opticsAllocationBudget - 1
        object = native.create(slot, node.model, native.offset(parent, pos), now)
    end
    if not object then return end
    if slot.angle ~= angle or not IsEntityAttachedToEntity(object, parent) then
        local rot = fixedRotation
        if node.axis then
            rot = {x=0, y=0, z=0}
            rot[node.axis] = angle
        end
        native.attach(object, parent, pos, rot, nil, true)
        if not IsEntityAttachedToEntity(object, parent) then native.lens(slot, object, 0); return end
        slot.angle = angle
    end
    native.lens(slot, object, visible and 100 or 0)
    return object
end

local function cacheFor(state, part)
    local c = { part = part, bodies = {}, points = {} }
    local function slot(id) return { diagnostic = part.id .. '/' .. id, initiallyHidden = true } end
    for _, body in ipairs(part.rig.bodies) do c.bodies[body.id] = slot(body.id) end
    for _, point in ipairs(part.rig.points) do c.points[point.id] = slot(point.id) end
    state.parts[part.id] = c
    return c
end

function M.draw(state, part, now, native)
    local cache = state.parts[part.id] or cacheFor(state, part)
    local rig, pose = part.rig, part.pose
    local delta = (now - part.receivedAt) % clockRange
    local position = pose.target
    if delta < pose.remainingMs then
        position = pose.position + (pose.target - pose.position) * (delta / pose.remainingMs)
    end
    local t = position * rig.duration
    for _, node in ipairs(rig.bodies) do
        local slot = cache.bodies[node.id]
        if node.parent then
            local fraction = math.max(0, math.min(1, (t - node.start) / node.duration))
            local angle = node.closed + (node.open - node.closed) * fraction
            slot.attached = place(state, slot, cache.bodies[node.parent].attached, node, node.offset, angle, nil, now, native, true)
        else
            slot.attached = place(state, slot, state.vehicle, node, part.position, 0, part.rotation, now, native, true)
        end
    end
    local mask
    if position == 1 and pose.target == 1 and pose.armed and not pose.paused then
        local mode = rig.modes[pose.mode]
        local phase = (pose.signalElapsedMs + delta) % mode.period
        for _, step in ipairs(mode.steps) do
            if phase < step.untilMs then mask = step.points; break end
        end
    end
    for _, p in ipairs(rig.points) do
        local slot = cache.points[p.id]
        if pose.target == 1 then
            place(state, slot, cache.bodies[p.parent].attached, p, p.offset, 0, zero, now, native, mask and mask[p.id])
        else
            hide(slot, native)
        end
    end
end

function M.remove(cache, discard)
    local clean = true
    for _, slot in pairs(cache.points) do
        if not discard(slot) then clean = false end
    end
    if not clean then return false end
    -- Keep the attachment ancestry intact while any child still awaits deletion.
    for i = #cache.part.rig.bodies, 1, -1 do
        if not discard(cache.bodies[cache.part.rig.bodies[i].id]) then return false end
    end
    return true
end

Dev01 = Dev01 or {}
Dev01.AuxPanel = M
