'use strict';

// JSON-only validation. Atelier can bundle this module without any FiveM or Node runtime API.
const schema = 'celk.auxiliary-panel';
const capabilities = Object.freeze(['rigid-sequence-v1', 'emissive-groups-v1']);
const identifier = /^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/;
const drawable = /^[a-z][a-z0-9_]{0,62}$/;
const reserved = new Set([...Object.getOwnPropertyNames(Object.prototype), 'prototype']);

function check(ok, field, message) {
    if (!ok) throw new Error('Panneau J · ' + field + ' · ' + message);
}

function keys(doc, expected, field) {
    check(doc && (Object.getPrototypeOf(doc) === Object.prototype || Object.getPrototypeOf(doc) === null),
        field, 'objet requis');
    const unknown = Object.keys(doc).find(name => !expected.includes(name));
    check(unknown === undefined, field, 'champ inconnu : ' + unknown);
    for (const name of expected) check(Object.hasOwn(doc, name), field, 'champ manquant : ' + name);
}

function string(value, field) {
    check(typeof value === 'string' && value.trim().length > 0 && [...value].length <= 64 &&
        !/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/u.test(value), field, 'libellé invalide (1–64 caractères)');
}

function id(value, field) {
    check(typeof value === 'string' && identifier.test(value) && !reserved.has(value), field, 'identifiant invalide');
}

function model(value, field) {
    check(typeof value === 'string' && drawable.test(value) && !reserved.has(value), field, 'nom de drawable invalide');
}

function list(values, min, max, field) {
    check(Array.isArray(values) && values.length >= min && values.length <= max &&
        Object.keys(values).length === values.length, field, 'liste attendue de ' + min + ' à ' + max + ' éléments');
}

function offset(value, field) {
    list(value, 3, 3, field);
    check(value.every(m => Number.isFinite(m) && Math.abs(m) <= 10), field, 'coordonnées en mètres hors de ±10');
}

function duration(value, field) {
    check(Number.isInteger(value) && value >= 50 && value <= 10000, field, 'durée entière de 50 à 10 000 ms requise');
}

function definedIds(rows, field, min, max, fields) {
    list(rows, min, max, field);
    const ids = new Set();
    for (const [i, row] of rows.entries()) {
        keys(row, fields, field + '[' + i + ']');
        id(row.id, field + '[' + i + '].id');
        check(!ids.has(row.id), field, 'identifiant répété : ' + row.id);
        ids.add(row.id);
    }
    return ids;
}

function refs(rows, known, min, field) {
    list(rows, min, known.size, field);
    const selected = new Set();
    for (const key of rows) {
        check(known.has(key), field, 'référence inconnue : ' + key);
        check(!selected.has(key), field, 'référence répétée : ' + key);
        selected.add(key);
    }
}

function modelsUsed(panel) {
    return new Set([...panel.bodies, ...panel.points].map(entry => entry.model));
}

function validatePanel(panel, availableModels) {
    keys(panel, ['schema','version','id','label','pieceKey','authoringModel','requires',
        'bodies','pivots','points','groups','modes','defaultMode'], 'contrat');
    check(panel.schema === schema && panel.version === 1, 'schema/version', 'format attendu : ' + schema + ' v1');
    id(panel.id, 'id');
    string(panel.label, 'label');
    id(panel.pieceKey, 'pieceKey');
    model(panel.authoringModel, 'authoringModel');
    list(panel.requires, 1, 12, 'requires');
    const required = new Set();
    for (const name of panel.requires) {
        check(capabilities.includes(name), 'requires', 'capacité non prise en charge : ' + name);
        check(!required.has(name), 'requires', 'capacité répétée : ' + name);
        required.add(name);
    }
    for (const name of capabilities) check(required.has(name), 'requires', 'capacité du schéma manquante : ' + name);

    const bodies = definedIds(panel.bodies, 'bodies', 2, 8, ['id','model']);
    for (const body of panel.bodies) model(body.model, 'bodies.' + body.id);
    const placed = new Set([panel.bodies[0].id]);
    let travel = 0;
    list(panel.pivots, bodies.size - 1, bodies.size - 1, 'pivots');
    for (const [i, pivot] of panel.pivots.entries()) {
        const field = 'pivots[' + i + ']';
        keys(pivot, ['body','parent','offset','axis','closedDeg','openDeg','durationMs'], field);
        check(bodies.has(pivot.body) && !placed.has(pivot.body), field, 'corps mobile absent ou répété');
        check(placed.has(pivot.parent), field, 'parent inconnu ou placé après son enfant : ' + pivot.parent);
        placed.add(pivot.body);
        offset(pivot.offset, field + '.offset');
        check(['x','y','z'].includes(pivot.axis), field, 'axe de pivot inconnu');
        check([pivot.closedDeg,pivot.openDeg].every(a => Number.isFinite(a) && Math.abs(a) <= 180) &&
            pivot.closedDeg !== pivot.openDeg, field, 'course angulaire invalide');
        duration(pivot.durationMs, field);
        travel += pivot.durationMs;
    }
    check(travel <= 30000, 'pivots', 'course totale supérieure à 30 000 ms');

    const points = definedIds(panel.points, 'points', 1, 32, ['id','body','model','offset']);
    for (const point of panel.points) {
        const field = 'points.' + point.id;
        check(bodies.has(point.body), field, 'corps inconnu : ' + point.body);
        model(point.model, field + '.model');
        offset(point.offset, field + '.offset');
    }
    const groups = definedIds(panel.groups, 'groups', 1, 16, ['id','points']);
    for (const group of panel.groups) refs(group.points, points, 1, 'groups.' + group.id);
    const modes = definedIds(panel.modes, 'modes', 1, 5, ['id','label','steps']);
    for (const mode of panel.modes) {
        const field = 'modes.' + mode.id;
        string(mode.label, field + '.label');
        list(mode.steps, 1, 32, field + '.steps');
        let period = 0;
        for (const [i, step] of mode.steps.entries()) {
            const key = field + '.steps[' + i + ']';
            keys(step, ['durationMs','groups'], key);
            duration(step.durationMs, key);
            refs(step.groups, groups, 0, key + '.groups');
            period += step.durationMs;
        }
        check(period <= 30000, field, 'période supérieure à 30 000 ms');
        check(mode.steps.some(step => step.groups.length > 0), field, 'aucune étape lumineuse');
    }
    check(modes.has(panel.defaultMode), 'defaultMode', 'mode inconnu : ' + panel.defaultMode);
    if (availableModels !== undefined) {
        const permits = new Set(availableModels);
        for (const name of modelsUsed(panel)) check(permits.has(name), 'model', 'drawable non déclaré : ' + name);
    }
    return panel;
}

module.exports = { schema, capabilities, validatePanel, modelsUsed };
