(() => {
    'use strict';

    const density = 3;

    function illustration(width, height, className, draw) {
        const canvas = document.createElement('canvas');
        canvas.className = className;
        canvas.width = width * density;
        canvas.height = height * density;
        canvas.setAttribute('aria-hidden', 'true');
        const ctx = canvas.getContext('2d');
        ctx.scale(density, density);
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
        draw(ctx);
        return canvas;
    }

    function box(ctx, x, y, width, height, radius, fill, edge) {
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.arcTo(x + width, y, x + width, y + height, radius);
        ctx.arcTo(x + width, y + height, x, y + height, radius);
        ctx.arcTo(x, y + height, x, y, radius);
        ctx.arcTo(x, y, x + width, y, radius);
        ctx.closePath();
        ctx.fillStyle = fill;
        ctx.fill();
        if (edge) {
            ctx.strokeStyle = edge;
            ctx.stroke();
        }
    }

    function dot(ctx, x, y, radius, color) {
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
    }

    // Rows are mirrored vertically. Each pair is the inclusive run of lit LEDs.
    const right = [
        [[10, 11]],
        [[10, 13]],
        [[1, 15]],
        [[1, 16]]
    ];
    const both = [
        [[5, 6], [10, 11]],
        [[3, 6], [10, 13]],
        [[1, 6], [10, 15]],
        [[0, 16]]
    ];

    function lampLit(key, col, row) {
        if (key === 'ligne') return row === 3 && col > 0 && col < 16;
        const at = key === 'gauche' ? 16 - col : col;
        const runs = key === 'double' ? both : right;
        return runs[Math.min(row, 6 - row)].some(([first, last]) => at >= first && at <= last);
    }

    function pattern(key) {
        return illustration(92, 32, 'signal-pattern', ctx => {
            const rim = ctx.createLinearGradient(0, 0, 0, 32);
            rim.addColorStop(0, '#a0a8ad');
            rim.addColorStop(0.16, '#444d53');
            rim.addColorStop(0.86, '#263037');
            rim.addColorStop(1, '#677278');
            ctx.lineWidth = 0.7;
            box(ctx, 1, 1, 90, 30, 5, rim, '#161b1e');
            box(ctx, 3, 3, 86, 26, 3.5, '#0d1113', '#151a1e');
            for (let row = 0; row < 7; row++) {
                for (let col = 0; col < 17; col++) {
                    const x = 8.4 + 4.7 * col;
                    const y = 5.95 + 3.35 * row;
                    if (lampLit(key, col, row)) {
                        dot(ctx, x, y, 2.05, '#784019');
                        dot(ctx, x, y, 1.61, '#ffbc4d');
                        dot(ctx, x - 0.18, y - 0.24, 0.85, '#ffe9a1');
                    } else {
                        dot(ctx, x, y, 0.97, '#33302a');
                    }
                }
            }
        });
    }

    function face(ctx, points, fill, edge) {
        ctx.beginPath();
        ctx.moveTo(...points[0]);
        for (const point of points.slice(1)) ctx.lineTo(...point);
        ctx.closePath();
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.strokeStyle = edge;
        ctx.stroke();
    }

    function shutter(open) {
        return illustration(138, 57, 'signal-shutter', ctx => {
            ctx.lineWidth = 0.9;

            // The roof pedestal stays still. The leaf rotates around its long hinge.
            face(ctx, [[8, 36], [99, 24], [131, 34], [39, 48]], '#343e45', '#a2aeb4');
            face(ctx, [[8, 36], [39, 48], [39, 54], [8, 42]], '#182126', '#657077');
            face(ctx, [[39, 48], [131, 34], [131, 40], [39, 54]], '#242e34', '#849198');
            face(ctx, [[17, 37], [99, 26], [121, 34], [40, 45]], '#10181d', '#4b5860');
            for (const [x, y] of [[13, 40], [44, 50], [123, 38]]) dot(ctx, x, y, 1, '#bbc1bd');

            ctx.save();
            // In local space y=21 is always the hinge, regardless of leaf angle.
            const depthX = open ? 0 : -0.86;
            const depthY = open ? 1.09 : -0.35;
            ctx.transform(1, -0.14, depthX, depthY, 20 - 21 * depthX, 37 - 21 * depthY);
            const plate = ctx.createLinearGradient(0, 0, 0, 21);
            plate.addColorStop(0, open ? '#586168' : '#414c52');
            plate.addColorStop(1, '#20292f');
            box(ctx, 0, 0, 88, 21, 1.6, plate, '#c0c8cb');
            box(ctx, 2.5, 2.3, 83, 16.9, 1, open ? '#1d2429' : '#303b41', '#59646a');
            if (open) {
                // Unlit lenses only: this picture describes the hinge, not a flash state.
                for (let x = 10; x <= 78; x += 10) {
                    dot(ctx, x, 10.5, 3.25, '#596168');
                    dot(ctx, x, 10.5, 2.35, '#21292f');
                    dot(ctx, x - 0.55, 9.85, 0.65, '#778087');
                }
            } else {
                for (const x of [14, 43, 72]) box(ctx, x, 4, 1.8, 13, 0.5, '#718087');
            }
            ctx.restore();

            for (const [x, y] of [[24, 36.5], [100, 26]]) {
                face(ctx, [[x - 3, y], [x + 5, y - 1], [x + 6, y + 1.5], [x - 2, y + 2.8]],
                    '#9ca8ab', '#333e45');
                dot(ctx, x - 1.7, y + 1.2, 1.1, '#dfdfd6');
            }
        });
    }

    // Rear view of the R01 board. The five middle lamps belong to both arrows.
    // The configurable scene lights on the truck are separate from these fifteen points.
    const bedLamps = [
        [25, 5, 'g'], [67, 5, 'd'], [17, 10, 'g'], [75, 10, 'd'],
        [8, 16, 'bgd'], [25, 16, 'bd'], [34, 16, 'bgd'], [46, 16, 'bgd'],
        [58, 16, 'bgd'], [67, 16, 'bg'], [84, 16, 'bgd'],
        [17, 22, 'g'], [75, 22, 'd'], [25, 27, 'g'], [67, 27, 'd'],
    ];

    function bedSignal(mode) {
        const channel = { barre: 'b', gauche: 'g', droite: 'd' }[mode];
        return illustration(92, 32, 'signal-pattern', ctx => {
            for (const [x, width] of [[2, 27], [30, 32], [63, 27]]) {
                box(ctx, x, 1.5, width, 29, 2.5, '#20281f', '#6b7567');
            }
            for (const [x, y, membership] of bedLamps) {
                const lit = membership.includes(channel);
                dot(ctx, x, y, lit ? 2.4 : 1.6, lit ? '#ffb82b' : '#49483a');
                if (lit) dot(ctx, x - .25, y - .2, 1.05, '#fff1b4');
            }
        });
    }

    function bed(open) {
        return illustration(138, 57, 'signal-shutter', ctx => {
            face(ctx, [[6, 39], [99, 30], [132, 38], [37, 51]], '#323e43', '#87979b');
            face(ctx, [[6, 39], [37, 51], [37, 55], [6, 43]], '#172024', '#647272');
            face(ctx, [[37, 51], [132, 38], [132, 42], [37, 55]], '#202a2e', '#839193');
            if (open) {
                ctx.save();
                ctx.transform(1, -.09, 0, 1, 18, 10);
                for (const [x, width] of [[0, 27], [28, 36], [65, 27]]) {
                    box(ctx, x, 0, width, 29, 2, '#26302b', '#a7b2a1');
                }
                for (const [x, y] of bedLamps) dot(ctx, x, y * .88 + .4, 1.5, '#655b43');
                ctx.restore();
            } else {
                for (let i = 0; i < 3; i++) {
                    const y = 36 - i * 3;
                    face(ctx, [[25, y], [83, y - 6], [105, y + 1], [47, y + 8]], '#344044', '#a0aba4');
                }
            }
        });
    }

    // A front view of the panel's lamps in its own mount coordinates. Every
    // child rotates around its parent-local pivot before the parent transform.
    function panelPoints(def, progress) {
        const duration = def.pivots.reduce((sum, pivot) => sum + pivot.durationMs, 0);
        let elapsed = progress * duration;
        const transforms = new Map([[def.bodies[0].id, point => point]]);
        for (const pivot of def.pivots) {
            const parent = transforms.get(pivot.parent);
            const fraction = Math.max(0, Math.min(1, elapsed / pivot.durationMs));
            const angle = (pivot.closedDeg + fraction * (pivot.openDeg - pivot.closedDeg)) * Math.PI / 180;
            const cos = Math.cos(angle), sin = Math.sin(angle);
            transforms.set(pivot.body, ([x,y,z]) => {
                const rotated = pivot.axis === 'x' ? [x, cos*y - sin*z, sin*y + cos*z] :
                    pivot.axis === 'y' ? [cos*x + sin*z, y, -sin*x + cos*z] : [cos*x - sin*y, sin*x + cos*y, z];
                return parent(rotated.map((value, i) => value + pivot.offset[i]));
            });
            elapsed -= pivot.durationMs;
        }
        return def.points.map(point => ({ id: point.id, xyz: transforms.get(point.body)(point.offset) }));
    }

    function panelDiagram(def, mode, pose) {
        const groups = new Map(def.groups.map(group => [group.id, group.points]));
        const steps = mode.steps.map(step => ({ duration: step.durationMs,
            lit: new Set(step.groups.flatMap(group => groups.get(group))) }));
        const cycle = steps.reduce((ms, step) => ms + step.duration, 0);
        const combined = new Set(steps.flatMap(step => [...step.lit]));
        const project = ({xyz:[x,y,z]}) => [x + .18*y,-z + .15*y];
        const open = panelPoints(def, 1);
        const chart = (pose ? [...open, ...panelPoints(def,0)] : open).map(project);
        const bounds = [0,1].map(i => [Math.min(...chart.map(p=>p[i])),Math.max(...chart.map(p=>p[i]))]);
        const center = bounds.map(([min,max]) => (min+max)/2);
        const zoom = Math.min(82 / Math.max(.1, bounds[0][1]-bounds[0][0]),
            26 / Math.max(.1, bounds[1][1]-bounds[1][0]));
        const canvas = illustration(92, 34, pose ? 'signal-shutter' : 'signal-pattern', () => {});
        const ctx = canvas.getContext('2d');
        const started = performance.now();
        function frame(time) {
            const elapsed = Math.max(0, time-started);
            const t = !pose ? 1 : pose.remainingMs <= elapsed ? pose.target :
                pose.position + (pose.target - pose.position) * elapsed / pose.remainingMs;
            let lit = combined;
            if (pose) {
                lit = undefined;
                if (pose.armed && !pose.paused && pose.target === 1 && t === 1) {
                    let phase = (pose.signalElapsedMs + elapsed) % cycle;
                    for (const step of steps) {
                        if (phase < step.duration) { lit = step.lit; break; }
                        phase -= step.duration;
                    }
                }
            }
            ctx.clearRect(0,0,92,34);
            box(ctx,1,1,90,32,4,'#202821','#656f64');
            for (const point of t === 1 ? open : panelPoints(def,t)) {
                const [u,v] = project(point);
                const x = 46 + (u-center[0])*zoom, y = 17 + (v-center[1])*zoom;
                const on = lit?.has(point.id);
                dot(ctx,x,y,on ? 2.25 : 1.45,on ? '#ffbd42' : '#655d4a');
                if (on) dot(ctx,x-.2,y-.2,.9,'#fff1b4');
            }
            if (pose && (pose.remainingMs > elapsed || (pose.armed && !pose.paused)) && canvas.isConnected
                && !canvas.closest('[hidden]')) requestAnimationFrame(frame);
        }
        frame(started);
        if (pose && (pose.remainingMs > 0 || (pose.armed && !pose.paused))) requestAnimationFrame(frame);
        return canvas;
    }

    window.CelkSignalArt = Object.freeze({ pattern, shutter, bedSignal, bed, panelDiagram });
})();
