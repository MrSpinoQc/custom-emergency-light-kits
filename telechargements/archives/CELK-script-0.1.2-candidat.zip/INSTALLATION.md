# Custom Emergency Light Kits

**Spino** · « Any vehicle. Your lights. Your way. »

Candidat privé de préparation, script `0.1.2`. Le pack séparé `phantom-grand-format@0.1.0` fournit un montage Police pour le Phantom GTA d’origine. Le reste des combinaisons de l’Atelier et les véhicules personnalisés sont hors de ce candidat. La licence de publication reste à choisir.

## Préparer un serveur d’essai

1. Utilise un FXServer configuré par l’administrateur, avec **OneSync**, GTA build cible **3889** et un artefact serveur **38435 ou supérieur** selon le manifeste de ce candidat. Le kit utilise Node 22 fourni par FXServer et CfxLua. Le poste d’essai doit avoir les moyens habituels de rejoindre le serveur et de sortir un Phantom existant.
2. Extrais `celk_runtime` et `celk_pack_phantom` comme deux ressources dans le dossier `resources`. Le script et le pack ont chacun leur version. Le pack fournit les accessoires et référence le modèle GTA `phantom`.
3. Dans `celk_runtime`, crée `local`. Copie `celk.config.example.json` vers `local/celk.config.json` et le contenu de `Modele-Phantom` du pack vers `local/models`. L’arborescence doit contenir `local/models/phantom/spino-r1/model-export.json` et le fichier de montage à côté.
4. Dans la configuration du serveur, déclare les permissions ACE sur des groupes dédiés. Ajoute les opérateurs prévus à ces groupes avec les mécanismes de gestion de ton serveur. Le groupe de liaison est réservé à l’opérateur qui attribue les identités durables.

```cfg
set onesync on
set sv_enforceGameBuild 3889

add_ace group.celk_operator celk.bind allow
add_ace group.celk_fitter celk.fit allow
add_ace group.celk_driver celk.drive allow

ensure celk_pack_phantom
ensure celk_runtime
```

5. Dans la console FXServer, lance `celk_preflight`. Vérifie le modèle, la révision et les diagnostics. Puis lance `celk_activate` pour écrire l’index et `restart celk_runtime` pour charger ce dernier. `celk_status` affiche les révisions, empreintes et variantes réellement chargées. Un précontrôle échoué laisse la sélection précédente en place.

## Monter et utiliser

- Au volant du Phantom arrêté, un opérateur ayant `celk.bind` entre `celk_bind <identifiant-durable>` dans F8, ou `/celk_bind <identifiant-durable>` dans le chat du jeu. L’ID est fourni par l’opérateur ou son registre de véhicules. Il doit distinguer les véhicules de même modèle. Réutilise cet ID pour le même véhicule après sa recréation ou après redémarrage. La plaque n’est pas la clé de sauvegarde.
- **F6** ouvre les variantes disponibles au conducteur ayant `celk.fit`. Une sélection valide remplace le montage et sauvegarde le couple service/variante. Le montage repart effets éteints.
- **J** choisit une scène et **Q** active ou coupe les éclats pour le conducteur ayant `celk.drive`. Les cinq scènes et la séquence d’origine sont conservées. Le Phantom r38 ne fournit pas de projecteur de scène ni de sirène dans ce candidat.
- `celk_unbind` libère l’entité et conserve son montage dans le fichier d’état. Pour reconstituer le montage, relie le véhicule concerné au même ID. Aucun garage tiers n’est inclus dans cette procédure.

## Diagnostic

- Ressource arrêtée, mauvais ordre ou version de pack non reconnue. Vérifie les noms de ressources et commence par `ensure celk_pack_phantom`, puis démarre le script.
- `Empreinte différente` ou `livraison ... incompatible`. Compare l’empreinte du manifeste et les fichiers aux reçus de la remise. Rétablis le lot exact et rejoue `celk_preflight`.
- Aucune variante. Vérifie `celk_status`, l’activation et le modèle d’origine. Le menu F6 requiert l’identité durable et la permission de pose.
- Les éclats restent éteints si le conducteur perd l’autorisation ou quitte le siège. Consulte le journal serveur et vérifie `celk.drive`.
- La touche est déjà utilisée par une autre ressource. Modifie son affectation CELK dans les paramètres de touches FiveM.
- `Variante sauvegardée retirée ou incompatible`. Consulte [Mises à jour et retour arrière](MISES-A-JOUR.md).

Le banc à partir des archives vérifie la lecture des fichiers, les routes et le rendu simulé. La référence humaine est l’éclairage r38 au labo. Voir la matrice de la remise pour les essais physiques du paquet candidat.
