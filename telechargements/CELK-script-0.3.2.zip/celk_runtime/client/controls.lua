local openMenu

local function stamp()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 or GetPedInVehicleSeat(vehicle, -1) ~= ped then return end
    local value = Entity(vehicle).state.celkMountStamp
    return type(value) == 'string' and value or nil
end

local function close()
    openMenu = nil
    SetNuiFocusKeepInput(false)
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'close' })
end

local function epoch()
    return GetNetworkTimeAccurate() % 4294967296
end

local function requestLights(current, desired, provider)
    if desired == nil then
        TriggerServerEvent('celk:operate', current, provider == 'lvc' and 'lvcToggle' or 'lights', '', epoch())
    else
        TriggerServerEvent('celk:operate', current, 'lightsState', desired and '1' or '0', epoch())
    end
end

exports('SetLvcLights', function(vehicle, desired)
    if GetInvokingResource() ~= 'lvc' or GetConvarInt('celk_lvc_enabled', 1) ~= 1 then return false end
    if desired ~= nil and type(desired) ~= 'boolean' then return false end
    if GetVehiclePedIsIn(PlayerPedId(), false) ~= vehicle then return false end
    local current = stamp()
    if not current then return false end
    requestLights(current, desired, 'lvc')
    return true
end)

exports('ToggleLvcSiren', function(vehicle)
    if GetInvokingResource() ~= 'lvc' or GetConvarInt('celk_lvc_enabled', 1) ~= 1
        or GetVehiclePedIsIn(PlayerPedId(), false) ~= vehicle then return false end
    local current = stamp()
    if not current then return false end
    TriggerServerEvent('celk:operate', current, 'lvcSiren', '', epoch())
    return true
end)

RegisterCommand('celk_lights', function()
    local current = stamp()
    if not current or openMenu or IsPauseMenuActive() or IsNuiFocused() then return end
    if GetConvarInt('celk_lvc_enabled', 1) == 1 and GetResourceState('lvc') == 'started' then
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        local ok, handled = pcall(function() return exports.lvc:HandleCELKQ(vehicle) end)
        if ok and handled == true then return end
    end
    requestLights(current, nil)
end, false)

RegisterCommand('celk_siren', function()
    local current = stamp()
    if not current or openMenu or IsPauseMenuActive() or IsNuiFocused() then return end
    if GetConvarInt('celk_lvc_enabled', 1) == 1 and GetResourceState('lvc') == 'started' then
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        local ok, handled = pcall(function() return exports.lvc:HandleCELKAlt(vehicle) end)
        if ok and handled == true then return end
    end
    TriggerServerEvent('celk:operate', current, 'siren', '', epoch())
end, false)

RegisterCommand('celk_scenes', function()
    if stamp() then TriggerServerEvent('celk:request', 'scenes') end
end, false)

RegisterCommand('celk_variants', function()
    if stamp() then TriggerServerEvent('celk:request', 'variants') end
end, false)

RegisterKeyMapping('celk_lights', 'CELK · Éclats', 'keyboard', 'Q')
RegisterKeyMapping('celk_siren', 'CELK · Sirène', 'keyboard', 'LMENU')
RegisterKeyMapping('celk_scenes', 'CELK · Scènes', 'keyboard', 'J')
RegisterKeyMapping('celk_variants', 'CELK · Montages', 'keyboard', 'F6')

for direction, hotkey in pairs({ left = 'NUMPAD4', right = 'NUMPAD6', up = 'NUMPAD8', down = 'NUMPAD2' }) do
    local aim = direction
    local name = 'celk_aim_' .. aim
    RegisterCommand(name, function()
        local current = stamp()
        if current and not openMenu then TriggerServerEvent('celk:operate', current, 'aim', aim, epoch()) end
    end, false)
    RegisterKeyMapping(name, 'CELK · Visée du projecteur ' .. hotkey, 'keyboard', hotkey)
end

RegisterNetEvent('celk:options', function(payload)
    local current = stamp()
    if source ~= 65535 or type(payload) ~= 'table' or
        not current or (payload.pane ~= 'variants' and payload.pane ~= 'scenes') or payload.stamp ~= current then return end
    openMenu = { pane = payload.pane, stamp = payload.stamp }
    SetNuiFocusKeepInput(false)
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'open', options = payload })
end)

RegisterNetEvent('celk:message', function(message)
    if source ~= 65535 or type(message) ~= 'string' or #message > 500 then return end
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandThefeedPostTicker(false, false)
end)

RegisterNUICallback('close', function(_, callback)
    close()
    callback({ ok = true })
end)

RegisterNUICallback('select', function(data, callback)
    if openMenu and openMenu.stamp == stamp() and type(data) == 'table' and type(data.id) == 'string' and #data.id <= 100 then
        TriggerServerEvent('celk:operate', openMenu.stamp, openMenu.pane == 'variants' and 'variant' or 'scene', data.id, epoch())
    end
    close()
    callback({ ok = true })
end)

RegisterNUICallback('projector', function(data, callback)
    if openMenu and openMenu.pane == 'scenes' and openMenu.stamp == stamp() and type(data) == 'table'
        and type(data.id) == 'string' and #data.id <= 64 then
        TriggerServerEvent('celk:operate', openMenu.stamp, 'projector', data.id, epoch())
    end
    close()
    callback({ ok = true })
end)

CreateThread(function()
    while true do
        if openMenu and openMenu.stamp ~= stamp() then close() end
        Wait(openMenu and 200 or 1000)
    end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(250) end
    -- Resync viewers joining after a mount was applied, or after a bucket change.
    while true do
        TriggerServerEvent('celk:request', 'state')
        Wait(8000)
    end
end)

AddEventHandler('onClientResourceStop', function(resource)
    if resource == GetCurrentResourceName() and openMenu then close() end
end)
