-- Sealed Studio rig SAD-3DPL-V05-FIVEM-0335-R01. Offsets are parent-local
-- GTA metres. Each drawable rotates around its own rebased origin.
local M = { renderer = 'sadler-trifold-j-r01', pieceId = 'sadler-benne-triple-01' }
local uint = 4294967296
local function vec(x, y, z) return { x = x, y = y, z = z } end
local zero = vec(0, 0, 0)
local centrePivot = vec(0, 0, .212)
local leftPivot = vec(-.421, .037, .85)
local rightPivot = vec(.421, .037, .85)
local points = {
    -- id, parent body, centre, masks in which this emissive is visible
    { 'G-haut',     'left',   vec(-.089,  -.085,  .3425), gauche = true },
    { 'D-haut',     'right',  vec( .0915, -.085,  .3425), droite = true },
    { 'G-diag-haut','left',   vec(-.2165, -.085,  .1725), gauche = true },
    { 'D-diag-haut','right',  vec( .2165, -.085,  .1725), droite = true },
    { 'G-pointe',   'left',   vec(-.3465, -.085, 0), barre = true, gauche = true, droite = true },
    { 'G-hampe',    'left',   vec(-.089,  -.085, 0), barre = true, droite = true },
    { 'C-gauche',   'centre', vec(-.2575, -.048, .85), barre = true, gauche = true, droite = true },
    { 'C-milieu',   'centre', vec(0,      -.048, .85), barre = true, gauche = true, droite = true },
    { 'C-droite',   'centre', vec( .255,  -.048, .85), barre = true, gauche = true, droite = true },
    { 'D-hampe',    'right',  vec( .0915, -.085, 0), barre = true, gauche = true },
    { 'D-pointe',   'right',  vec( .3465, -.085, 0), barre = true, gauche = true, droite = true },
    { 'G-diag-bas', 'left',   vec(-.2165, -.085, -.1725), gauche = true },
    { 'D-diag-bas', 'right',  vec( .2165, -.085, -.1725), droite = true },
    { 'G-bas',      'left',   vec(-.089,  -.085, -.345), gauche = true },
    { 'D-bas',      'right',  vec( .0915, -.085, -.345), droite = true },
}
local modes = { barre = true, gauche = true, droite = true }

function M.validate(part, pose, v, now)
    if part.id ~= M.pieceId or part.model ~= 'ta_sad_trifold_v5' or #part.optics ~= 0
        or type(pose) ~= 'table' or not v.bounded(pose.position, 0, 1) or (pose.target ~= 0 and pose.target ~= 1)
        or not v.bounded(pose.remainingMs, 0, 3000) or not v.bounded(pose.signalElapsedMs, 0, 9007199254740991)
        or type(pose.mode) ~= 'string' or not modes[pose.mode] or type(pose.armed) ~= 'boolean'
        or type(pose.paused) ~= 'boolean' then return end
    local fullTime = math.abs(pose.target - pose.position) * 3000
    if math.abs(fullTime - pose.remainingMs) > 1
        or (pose.armed and (pose.position ~= 1 or pose.target ~= 1 or pose.remainingMs ~= 0)) then return end
    part.kind, part.geometry = M.renderer, M.renderer
    part.pose, part.receivedAt = pose, now
    return part
end

local function position(part, delta)
    local pose = part.pose
    if delta >= pose.remainingMs then return pose.target end
    return pose.position + (pose.target - pose.position) * (delta / pose.remainingMs)
end

local function segment(t) return math.max(0, math.min(1, t)) end

local function hide(slot, native)
    native.release(slot)
    if native.valid(slot) then native.lens(slot, slot.object, 0) end
end

-- Share the accessory overlay budget with the nine other mounted pieces.
-- Even an object waiting for its model consumes at most one attempt this tick.
local function place(state, slot, parent, model, pos, rot, angle, now, native, visible)
    if not parent then hide(slot, native); return end
    local object
    if native.valid(slot) then
        object = slot.object
    elseif state.opticsAllocationBudget > 0 and (not slot.retry or now >= slot.retry) then
        state.opticsAllocationBudget = state.opticsAllocationBudget - 1
        object = native.create(slot, model, native.offset(parent, pos), now)
    end
    if not object then return end
    if angle ~= slot.angle or not IsEntityAttachedToEntity(object, parent) then
        native.attach(object, parent, pos, rot, nil, true)
        if not IsEntityAttachedToEntity(object, parent) then
            native.lens(slot, object, 0)
            return
        end
        slot.angle = angle
    end
    native.lens(slot, object, visible and 100 or 0)
    return object
end

function M.draw(state, part, now, native)
    local cache = state.parts[part.id]
    if not cache then
        local function slot(id) return { initiallyHidden = true, diagnostic = part.id .. '/' .. id } end
        cache = { part = part, support = slot('support'), centre = slot('centre'), left = slot('gauche'),
            right = slot('droite'), lenses = {} }
        for _, point in ipairs(points) do cache.lenses[point[1]] = slot(point[1]) end
        state.parts[part.id] = cache
    end
    local delta = (now - part.receivedAt) % uint
    local t = 3 * position(part, delta)
    local centreAngle = -90 * (1 - segment(t))
    local leftAngle = -180 * (1 - segment(t - 1))
    local rightAngle = 180 * (1 - segment(t - 2))
    local support = place(state, cache.support, state.vehicle, 'ta_sad_v5j_support', part.position,
        part.rotation, 0, now, native, true)
    local centre = place(state, cache.centre, support, 'ta_sad_v5j_centre', centrePivot,
        vec(centreAngle, 0, 0), centreAngle, now, native, true)
    local left = place(state, cache.left, centre, 'ta_sad_v5j_gauche', leftPivot,
        vec(0, 0, leftAngle), leftAngle, now, native, true)
    local right = place(state, cache.right, centre, 'ta_sad_v5j_droite', rightPivot,
        vec(0, 0, rightAngle), rightAngle, now, native, true)
    local parents = { centre = centre, left = left, right = right }
    local pose = part.pose
    local on = pose.target == 1 and t == 3 and pose.armed and not pose.paused
        and (pose.signalElapsedMs + delta) % 1000 < 500
    for _, point in ipairs(points) do
        local slot = cache.lenses[point[1]]
        if pose.target == 1 then
            -- Preload while unfolding so the first 500 ms pulse is complete.
            -- The Studio drawable already includes its 0.35 mm surface offset.
            place(state, slot, parents[point[2]], 'ta_sad_v5j_ambre', point[3], zero, 0, now, native,
                on and point[pose.mode] == true)
        else
            hide(slot, native)
        end
    end
end

function M.remove(cache, discard)
    local clean = true
    for _, slot in pairs(cache.lenses) do
        if not discard(slot) then clean = false end
    end
    if not clean then return false end
    local leftGone, rightGone = discard(cache.left), discard(cache.right)
    return leftGone and rightGone and discard(cache.centre) and discard(cache.support)
end

Dev01 = Dev01 or {}
Dev01.SadlerTrifold = M
