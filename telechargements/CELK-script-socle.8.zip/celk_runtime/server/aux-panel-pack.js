'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { sha256 } = require('./model-exports.js');
const { validatePanel, modelsUsed } = require('./aux-panel-contract.js');

const renderer = 'celk-auxiliary-panel-v1';
const digest = /^[a-f0-9]{64}$/;
const packId = /^[a-z0-9][a-z0-9-]{0,63}$/;
const versionId = /^[0-9]+\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9.-]+)?$/;
const nativePath = /^stream\/(?:celk|ta|ta01|ta_pack)_[a-z0-9][a-z0-9_]{0,52}\.(?:ydr|ytyp)$/;
function need(ok, message) { if (!ok) throw Error('Pack panneau J · ' + message); }
function fields(doc, names) {
    return doc && Object.getPrototypeOf(doc) === Object.prototype &&
        Object.keys(doc).length === names.length && names.every(key => Object.hasOwn(doc,key));
}

function readPanelPack(base, spec, descriptor, regular, streamDeclarations) {
    const keys = ['schema','version','id','packVersion','author','studioRevision','renderer','panel','files','assetSources','fxmanifestSha256'];
    need(fields(descriptor, keys) && descriptor.schema === 'tryagain.piece-pack' && descriptor.version === 2 &&
        descriptor.renderer === renderer && descriptor.id === spec.id && descriptor.packVersion === spec.version &&
        packId.test(spec.id) && versionId.test(spec.version), 'manifeste ou identité incompatible');
    need([descriptor.author,descriptor.studioRevision].every(value => typeof value === 'string' && value.trim() &&
        value.length <= 120 && !/[\x00-\x1f\x7f]/.test(value)), 'provenance absente ou invalide');
    need(digest.test(descriptor.fxmanifestSha256), 'empreinte du fxmanifest invalide');
    need(Array.isArray(descriptor.assetSources) && descriptor.assetSources.length <= 8, 'liste des sources de drawables invalide');
    const ids = new Set([spec.id]);
    for (const source of descriptor.assetSources) {
        need(fields(source,['id','version','sha256']) && typeof source.id === 'string' && packId.test(source.id) &&
            typeof source.version === 'string' && source.version.length <= 64 && versionId.test(source.version) &&
            typeof source.sha256 === 'string' && digest.test(source.sha256) && !ids.has(source.id),
        'source absente, répétée ou non épinglée');
        ids.add(source.id);
    }
    need(descriptor.files && Object.getPrototypeOf(descriptor.files) === Object.prototype,
        'inventaire des flux invalide');
    const files = Object.entries(descriptor.files);
    need(files.length <= 56 && files.every(([file, hash]) => nativePath.test(file) && typeof hash === 'string' && digest.test(hash)),
        'nom ou empreinte de flux invalide');
    const yt = new Set(files.map(([name]) => name).filter(name => name.endsWith('.ytyp')));
    need((files.length === 0 && descriptor.assetSources.length > 0) ||
        (files.length > 0 && yt.size >= 1 && yt.size <= 8 && yt.size < files.length), 'inventaire de drawables et YTYP incomplet');
    const expectedRoot = ['fxmanifest.lua','pack-manifest.json'];
    if (files.length) expectedRoot.push('stream');
    const listEquals = (a,b) => a.length === b.length && a.every((value,i) => value === b[i]);
    need(listEquals(fs.readdirSync(base).sort(),expectedRoot.sort()), 'fichier imprévu à la racine de la ressource');
    if (files.length) {
        const stream = path.join(base,'stream');
        need(fs.lstatSync(stream).isDirectory() && fs.realpathSync(stream) === stream, 'dossier de streaming redirigé');
        need(listEquals(fs.readdirSync(stream).sort(),files.map(([name]) => path.posix.basename(name)).sort()),
            'fichier natif absent ou supplémentaire');
    }
    const fx = regular(base,'fxmanifest.lua',8192);
    need(sha256(fx) === descriptor.fxmanifestSha256,'fxmanifest différent');
    streamDeclarations(fx.toString('utf8'),yt,spec.version);
    for (const [name,hash] of files) {
        const bytes = regular(base,name,8*1024*1024);
        need(sha256(bytes) === hash && bytes.subarray(0,4).toString('ascii') === 'RSC7', 'flux natif différent : ' + name);
    }
    const assets = files.map(([name]) => name).filter(name => name.endsWith('.ydr')).map(name => path.posix.basename(name,'.ydr'));
    const panel = validatePanel(descriptor.panel, descriptor.assetSources.length ? undefined : assets);
    return { id:spec.id, resource:spec.resource, version:spec.version, sha256:spec.sha256, renderer,
        assets, types:[...yt].map(name=>path.posix.basename(name,'.ytyp')), parts:new Map(),
        panel, panelDigest:spec.sha256, assetSources:descriptor.assetSources };
}

// Resolve only the packs selected for the variant; a resource merely present on disk grants no models.
function resolvePanelModels(pack, resolvedPacks) {
    const permitted = new Set(pack.assets);
    for (const source of pack.assetSources) {
        const owner = resolvedPacks.find(candidate => candidate.id === source.id);
        need(owner && owner.version === source.version && owner.sha256 === source.sha256,
            'source requise absente ou empreinte différente : ' + source.id + '@' + source.version);
        need(owner.renderer !== renderer, 'référence de panneau à panneau non prise en charge : ' + source.id);
        for (const name of owner.assets || []) {
            need(!permitted.has(name), 'plusieurs sources pour le drawable ' + name);
            permitted.add(name);
        }
    }
    for (const name of modelsUsed(pack.panel)) need(permitted.has(name), 'drawable non fourni par les dépendances : ' + name);
    return pack.panel;
}

module.exports = { renderer, readPanelPack, resolvePanelModels, modelsUsed };
