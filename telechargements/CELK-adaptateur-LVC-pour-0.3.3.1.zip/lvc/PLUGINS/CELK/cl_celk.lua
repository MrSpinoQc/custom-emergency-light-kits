-- Raccord Try Again pour LVC 3.2.9 Rev2. LVC garde ses commandes natives de classe 18.
local runtime = 'celk_runtime'

local function isDriver(vehicle)
    local ped = PlayerPedId()
    return vehicle ~= 0 and GetVehiclePedIsIn(ped, false) == vehicle and GetPedInVehicleSeat(vehicle, -1) == ped
end

local function mounted(vehicle)
    return isDriver(vehicle) and type(Entity(vehicle).state.celkMountStamp) == 'string'
end

exports('HandleCELKQ', function(vehicle)
    if GetInvokingResource() ~= runtime or GetConvarInt('celk_lvc_enabled', 1) ~= 1 or not mounted(vehicle) then return false end
    if GetVehicleClass(vehicle) ~= 18 then
        SetTimeout(0, function()
            if mounted(vehicle) and GetResourceState(runtime) == 'started' then
                exports[runtime]:SetLvcLights(vehicle)
            end
        end)
    end
    return true
end)

exports('HandleCELKAlt', function(vehicle)
    if GetInvokingResource() ~= runtime or GetConvarInt('celk_lvc_enabled', 1) ~= 1 or not mounted(vehicle) then return false end
    -- Ici la classe 18 reste sous le contrôle radio et sirène du LVC natif.
    if GetVehicleClass(vehicle) == 18 then return true end
    SetTimeout(0, function()
        if mounted(vehicle) and GetResourceState(runtime) == 'started' then
            exports[runtime]:ToggleLvcSiren(vehicle)
        end
    end)
    return true
end)

exports('CelkSirenTone', function(vehicle, service)
    if GetInvokingResource() ~= runtime or GetConvarInt('celk_lvc_enabled', 1) ~= 1
        or not DoesEntityExist(vehicle) or (service ~= 'police' and service ~= 'ambulance') then return end
    local model = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
    local choices = SIREN_ASSIGNMENTS[model]
    local default = service == 'ambulance' and 11 or 2
    local tone = SIRENS[choices and choices[2] or default]
    if tone then return tone.String, tone.Ref end
end)

CreateThread(function()
    local lastVehicle, lastStamp, lastLights
    while true do
        local delay = 100
        if GetConvarInt('celk_lvc_enabled', 1) == 1 and GetResourceState(runtime) == 'started' then
            local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            local active = mounted(vehicle)
            if active and GetVehicleClass(vehicle) == 18 then
                local stamp = Entity(vehicle).state.celkMountStamp
                local lights = IsVehicleSirenOn(vehicle)
                if vehicle ~= lastVehicle or stamp ~= lastStamp then
                    lastVehicle, lastStamp, lastLights = vehicle, stamp, lights
                elseif lights ~= lastLights then
                    lastLights = lights
                    exports[runtime]:SetLvcLights(vehicle, lights)
                end
            else
                lastVehicle, lastStamp, lastLights = nil, nil, nil
                if active and not IsPauseMenuActive() and not IsNuiFocused() then
                    -- LVC bloque cette commande native sur la classe 18. Le véhicule civil
                    -- équipé utilise le même raccourci Q pour les éclats du pack.
                    DisableControlAction(0, 85, true) -- INPUT_VEH_RADIO_WHEEL
                    DisableControlAction(0, 19, true) -- INPUT_CHARACTER_WHEEL
                    delay = 0
                end
            end
        end
        Wait(delay)
    end
end)
