'use strict';

const mechanism = require('./aux-panel-state.js');

const modes = new Map([['barre', 'Barre'], ['gauche', 'Flèche gauche'], ['droite', 'Flèche droite']]);

function initial(model, variant, parts) {
    if (model !== 'sadler' || variant?.service !== 'mecano' || variant.scenePlayback !== 'service-j-v1' ||
        !parts.some(part => part.id === 'sadler-benne-triple-01' && part.model === 'ta_sad_trifold_v5' &&
            part.trifold === 'sadler-trifold-j-r01')) return;
    return mechanism.create(3000, modes, 'barre');
}

function options(state) {
    return [{ id: 'open', label: 'Déployer la benne', on: state.motion.to === 1 },
        { id: 'close', label: 'Replier la benne', on: state.motion.to === 0 },
        ...Array.from(modes, ([mode, label]) => ({ id: 'mode:' + mode, label, on: state.mode === mode })),
        { id: state.armed ? 'signal:off' : 'signal:on', label: state.armed ? 'Couper le signal' : 'Armer le signal',
            on: state.armed, disabled: state.motion.to === 0 },
        { id: state.paused ? 'pause:off' : 'pause:on', label: state.paused ? 'Reprendre le signal' : 'Pause du signal',
            on: state.paused, disabled: !state.armed }];
}

module.exports = { initial, command: mechanism.command, stop: mechanism.stop, snapshot: mechanism.snapshot, options };
