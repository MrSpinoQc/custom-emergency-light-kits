'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { isDeepStrictEqual: same } = require('node:util');
const { sha256 } = require('./model-exports.js');
const common = require('./common-optics.js');

const renderer = 'sadler-trifold-v05';
const id = 'sadler-benne-equipement-v05';
const version = '0.5.0';
const resource = 'ta_sad_trifold_v5';
const runtime = '0.3.3-sadler.5';
const playback = 'service-j-v1';
const blackCabochons = Object.freeze({
    optics: Object.freeze({
        version: '0.5.1', sha256: '02098c3bfe7f52cb90954c2b9073164319b877941f782bebdb7b7cc251b01e8d',
    }),
    articulation: Object.freeze({
        version: '0.1.1', sha256: 'de6f5b0a9c0d245cc3a0d970f9ee871afb4647863d78e3a51f97ed1b43fe6ff5',
        fxmanifestSha256: 'f41094e5783e0f85192a5bfe041bb80da3c99d55170d021c65f9f352f6178493',
    }),
});
const articulated = Object.freeze({
    id: 'sadler-benne-articulation-r01', version: '0.1.0', resource: 'celk_sadler_trifold_r01',
    renderer: 'sadler-trifold-j-r01', runtime: '0.3.3-sadler.6',
    sha256: '597e2664a8cafd51575eec4e26af48cfe4bb9177dc8cf517ffd7d90a06068c6f',
    fxmanifestSha256: '6e555d290f6bf526e4263259f3da35028298f008152c1c58747215d86cb4b4c6',
    mountSha256: 'f0f6c5aaac42d20996a2027cb4578ac71c97f89c34ad4b40e90ed587e9e254fc',
    piece: 'sadler-benne-triple-01',
});
const plain = value => value !== null && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype;
function check(valid, message) {
    if (!valid) throw new Error('Sadler V05 : ' + message);
}

function readArticulation(base, spec, descriptor, regular, streamDeclarations) {
    const pin = spec.version === blackCabochons.articulation.version ? blackCabochons.articulation : articulated;
    check(descriptor.id === articulated.id && spec.resource === articulated.resource && spec.version === pin.version &&
        spec.sha256 === pin.sha256 && descriptor.renderer === articulated.renderer,
    'articulation R01 : identité ou empreinte différente de l’adaptateur');
    const files = Object.entries(descriptor.files);
    const names = files.map(([file]) => path.posix.basename(file));
    const types = new Set(files.map(([file]) => file).filter(file => file.endsWith('.ytyp')));
    const stream = path.join(base, 'stream');
    check(files.length === 6 && types.size === 1 && same(fs.readdirSync(base).sort(), ['fxmanifest.lua', 'pack-manifest.json', 'stream']) &&
        fs.lstatSync(stream).isDirectory() && fs.realpathSync(stream) === stream && same(fs.readdirSync(stream).sort(), names.sort()),
    'articulation R01 : inventaire natif divergent');
    const lua = regular(base, 'fxmanifest.lua', 8192);
    check(sha256(lua) === pin.fxmanifestSha256, 'articulation R01 : fxmanifest.lua différent');
    streamDeclarations(lua.toString('utf8'), types, spec.version);
    for (const [file, hash] of files) {
        const bytes = regular(base, file, 2 * 1024 * 1024);
        check(sha256(bytes) === hash && bytes.toString('ascii', 0, 4) === 'RSC7', 'articulation R01 : flux différent : ' + file);
    }
    return { id: descriptor.id, version: spec.version, resource: spec.resource, sha256: spec.sha256, renderer: articulated.renderer, parts: new Map(),
        assets: names.filter(name => name.endsWith('.ydr')).map(name => path.basename(name, '.ydr')),
        types: [...types].map(name => path.posix.basename(name, '.ytyp')) };
}

function readPack(base, spec, descriptor, regular, streamDeclarations) {
    const reference = require('./sadler-v05-reference.json');
    const pin = spec.version === blackCabochons.optics.version ? blackCabochons.optics : reference.pack;
    check(descriptor.id === id && spec.resource === resource && spec.version === pin.version &&
        spec.sha256 === pin.sha256 && descriptor.renderer === renderer,
    'identité ou empreinte différente de la ressource Studio préparée');
    const entries = Object.entries(descriptor.files);
    const names = entries.map(([name]) => name);
    const types = new Set(names.filter(name => name.endsWith('.ytyp')));
    check(entries.length === 48 && types.size === 10 && names.every(name => /^stream\/[a-z0-9_]+\.(ydr|ytyp)$/.test(name)),
        'inventaire attendu de 38 YDR et 10 YTYP');
    check(same(fs.readdirSync(base).sort(), ['fxmanifest.lua', 'pack-manifest.json', 'stream']),
        'inventaire de la ressource inattendu');
    const stream = path.join(base, 'stream');
    check(fs.lstatSync(stream).isDirectory() && fs.realpathSync(stream) === stream &&
        same(fs.readdirSync(stream).sort(), names.map(name => path.posix.basename(name)).sort()),
    'flux supplémentaire, manquant ou redirigé');
    streamDeclarations(regular(base, 'fxmanifest.lua', 8192).toString('utf8'), types, spec.version);
    for (const [file, hash] of entries) {
        const bytes = regular(base, file, 8 * 1024 * 1024);
        check(bytes.toString('ascii', 0, 4) === 'RSC7' && sha256(bytes) === hash, 'flux Studio différent : ' + file);
    }
    const capabilities = { fixedBodies: 1, opticPalettes: 1, lightScenes: 2, lensDiffusion: 1 };
    const expectedModels = new Set(names.filter(name => name.endsWith('.ydr')).map(name => path.posix.basename(name, '.ydr')));
    const remaining = new Set(expectedModels);
    const reserve = name => check(remaining.delete(name), 'drawable absent ou répété dans le catalogue : ' + name);
    const luminous = reference.parts.filter(part => part.model !== resource).map(({ model, optics }) => ({ model, optics }));
    const parts = common.readParts({ capabilities, parts: luminous }, reserve);
    reserve(resource);
    parts.set(resource, { optics: new Map() });
    check(remaining.size === 0 && parts.size === 10, 'catalogue incomplet');
    return { id, version: spec.version, resource, renderer, studioRevision: 'V05', capabilities, parts,
        assets: [...expectedModels], types: [...types].map(name => path.posix.basename(name, '.ytyp')) };
}

function hiddenExtras(doc) {
    const settings = doc.project.vehicleSettings?.sadler;
    const gta = doc.optionsGta;
    if (settings === undefined && gta === undefined) return [];
    check(plain(settings) && plain(settings.visibility) && plain(gta) && Array.isArray(gta.pieces) &&
        Object.keys(gta).every(key => ['vehicule', 'livree', 'livreeGta', 'pieces'].includes(key)) &&
        gta.vehicule === 'sadler' && gta.livree == null && gta.livreeGta == null &&
        gta.pieces.length <= 21, 'options GTA inconnues ou incomplètes');
    const visibility = {};
    const ids = gta.pieces.map(row => {
        check(plain(row) && Object.keys(row).every(key =>
            ['id','nom','type','extra','kit','index','categorie','source','visible','origine','position','rotation'].includes(key)) &&
            row.type === 'extra' && Number.isInteger(row.extra) && row.extra >= 0 && row.extra <= 20 &&
            row.id === 'extra-' + row.extra && row.visible === false && row.index == null && row.kit == null &&
            row.categorie == null && typeof row.source === 'string' && typeof row.nom === 'string' &&
            Array.isArray(row.origine) && row.origine.length === 3 && row.origine.every(Number.isFinite) &&
            same(row.position, row.origine) && same(row.rotation, [0, 0, 0]) && !Object.hasOwn(visibility, row.id),
        'seuls les extras d’origine masqués sont décrits par ce raccord');
        visibility[row.id] = false;
        return row.extra;
    });
    check(same(visibility, settings.visibility), 'visibilité GTA divergente entre les deux copies');
    return ids;
}

function compileMount(input) {
    const { doc, model, service, packs } = input;
    const opticsPack = packs.find(pack => pack.renderer === renderer);
    const mechanism = packs.find(pack => pack.renderer === articulated.renderer);
    check(model === 'sadler' && service === 'mecano' && opticsPack && packs.length === (mechanism ? 2 : 1),
        'Sadler Remorqueur et ressource V05 requis ; seul l’auxiliaire R01 est admis en complément');
    if (mechanism) check((opticsPack.version === blackCabochons.optics.version) ===
        (mechanism.version === blackCabochons.articulation.version), 'révisions statique et articulée divergentes');
    if (mechanism) check(sha256(input.bytes) === articulated.mountSha256,
        'articulation R01 : montage auteur différent de la révision qualifiée');
    const extras = hiddenExtras(doc);
    const diffusions = doc.diffusionsLentilles;
    check(Array.isArray(diffusions) && diffusions.length <= 20, 'diffusions résolues du montage requises');
    // R04 keeps only the user's edits locally. The parallel wire block holds the fully resolved values.
    // Materialise only declared fields, after comparing every editor override to its resolved counterpart.
    const attachments = doc.project.attachments.map(item => {
        if (item.lensDiffusion === undefined) return item;
        check(plain(item.lensDiffusion), 'diffusions locales invalides');
        const row = diffusions.find(row => row?.pieceKey === item.key);
        check(Array.isArray(row?.optics), 'diffusion résolue manquante pour ' + item.key);
        const resolved = {};
        for (const [opticId, edits] of Object.entries(item.lensDiffusion)) {
            const entry = row.optics.find(optic => optic?.id === opticId);
            check(plain(edits) && entry, 'diffusion locale non résolue : ' + item.key + '/' + opticId);
            const { id, emitters, ...values } = entry;
            check(Object.entries(edits).every(([key, value]) => Object.hasOwn(values, key) && same(values[key], value)),
                'diffusion locale et résolue divergentes : ' + item.key + '/' + id);
            resolved[id] = values;
        }
        return { ...item, lensDiffusion: resolved };
    });
    const normalized = { ...doc, project: { ...doc.project, attachments } };
    if (doc.optionsGta !== undefined) {
        normalized.optionsGta = { ...doc.optionsGta, pieces: [] };
        normalized.project.vehicleSettings = { ...doc.project.vehicleSettings, sadler: {
            ...doc.project.vehicleSettings.sadler, visibility: {},
        } };
    }
    const compiled = common.compileMount({ ...input, doc: normalized, packs: [opticsPack] });
    if (mechanism) {
        const bed = compiled.renderedParts.find(part => part.id === articulated.piece);
        check(bed?.model === resource && bed.optics.length === 0, 'articulation R01 : benne du montage introuvable');
        bed.trifold = articulated.renderer;
    }
    return { ...compiled, scenePlayback: playback, hiddenExtras: extras };
}

module.exports = { renderer, id, version, resource, runtime, playback, articulated, blackCabochons, readPack, readArticulation, compileMount };
