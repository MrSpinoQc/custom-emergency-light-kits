'use strict';

const menu = document.querySelector('#menu');
const choices = document.querySelector('#choices');
const close = document.querySelector('#close');
const status = document.querySelector('#status');
const titles = new Map([['police', 'Police'], ['ambulance', 'Ambulance'], ['mecano', 'Mécano']]);
const pictograms = {
    line: ['lamp-row'],
    left: ['arrow-mark is-left'],
    right: ['arrow-mark'],
    up: ['arrow-mark is-up'],
    down: ['arrow-mark is-down'],
    both: ['arrow-mark is-left', 'arrow-mark'],
    target: ['target-mark'],
};
let session, pending, movementTimer;
const panelTimers = new Set();

function clearMotion() {
    clearTimeout(movementTimer);
    for (const timer of panelTimers) clearTimeout(timer);
    panelTimers.clear();
}

function node(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = text;
    return el;
}

function announce(text) {
    status.textContent = text ?? '';
    status.hidden = !text;
    fitLighting();
}

function fitLighting() {
    if (menu.hidden || !menu.classList.contains('lighting')) return;
    const { offsetWidth: width, offsetHeight: height } = menu;
    // The rounding margin keeps the box below one eighth even after subpixel layout.
    const available = window.innerWidth * window.innerHeight * .123;
    const scale = Math.min(1, Math.sqrt(available / (width * height)), window.innerHeight * .94 / height);
    menu.style.setProperty('--panel-scale', scale);
}

async function send(route, data = {}) {
    const token = { session };
    if (route === 'action') {
        if (pending) return;
        pending = token;
        menu.setAttribute('aria-busy', 'true');
    }
    try {
        const response = await fetch('https://' + GetParentResourceName() + '/' + route, {
            method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify({ ...data, session: token.session }),
        });
        if (!response.ok || (await response.json())?.ok !== true) throw Error();
    } catch {
        if (route === 'action' && pending === token) {
            pending = undefined;
            menu.removeAttribute('aria-busy');
            announce('Commande indisponible. Vérifie le montage ou réessaie.');
        }
    }
}

function pictogram(name) {
    const symbol = node('span', 'mode-icon');
    symbol.setAttribute('aria-hidden', 'true');
    for (const shape of pictograms[name]) symbol.append(node('span', shape));
    return symbol;
}

function action(item, type, { label = item.label, active, className = '', icon, iconOnly = false } = {}) {
    const button = node('button', className);
    button.type = 'button';
    button.dataset.action = type;
    button.dataset.id = item.id;
    if (typeof active === 'boolean') button.setAttribute('aria-pressed', String(active));
    if (icon) {
        button.append(pictogram(icon));
        button.title = label;
        if (iconOnly) button.setAttribute('aria-label', label);
        else button.append(node('span', '', label));
    } else {
        button.textContent = label;
    }
    button.addEventListener('click', () => send('action', { action: type, id: item.id }));
    return button;
}

function section(title, className = '', heading = 'h2') {
    const card = node('section', 'card ' + className);
    card.append(node(heading, '', title));
    return card;
}

function showMounts(items, selected) {
    for (const item of items) {
        const installed = item.id === selected;
        const card = node('article', 'card mount-card' + (installed ? ' installed' : ''));
        const detail = node('div');
        const service = titles.get(item.service) ?? item.service;
        detail.append(node('h2', '', item.label));
        if (service && service !== item.label) detail.append(node('p', 'detail', service));
        card.append(detail, installed
            ? node('span', 'selected-label', '✓ Installé')
            : action(item, 'variant', { label: 'Installer', className: 'primary' }));
        if (!installed) card.lastElementChild.setAttribute('aria-label', 'Installer ' + item.label);
        choices.append(card);
    }
    if (!items.length) announce('Aucun montage disponible pour ce véhicule.');
}

function showRamp(options, container) {
    const byId = new Map(options.rampControls.map(item => [item.id, item]));
    const rampAction = (id, properties) => action(byId.get(id), 'sadler', properties);
    const trifold = options.rampMotion?.kind === 'trifold';
    const grid = node('div', trifold ? 'ramp-grid trifold-grid' : 'ramp-grid');
    const open = byId.get('open').on === true;
    const moving = options.rampMotion?.remainingMs > 0;
    const shutter = section(trifold ? 'Benne' : 'Volet', 'stack shutter', 'h3');
    const shutterRow = node('div', 'shutter-control');
    const settled = trifold ? (open ? 'Déployée' : 'Repliée') : (open ? 'Déployé' : 'Replié');
    const state = node('p', 'shutter-state', moving ? (open ? 'Déploiement…' : 'Repli…') : settled);
    const symbol = trifold ? window.CelkSignalArt.bed(open) : window.CelkSignalArt.shutter(open);
    shutterRow.append(symbol, state, rampAction(open ? 'close' : 'open', {
        label: open ? 'Replier' : 'Déployer', className: 'primary',
    }));
    shutter.append(shutterRow);
    const presets = section(trifold ? 'Signal de benne' : 'Motif du volet', 'motifs', 'h3');
    const controlRow = node('div', 'section-heading');
    const armId = trifold ? (byId.has('signal:off') ? 'signal:off' : 'signal:on') : 'armed';
    const pauseId = trifold ? (byId.has('pause:off') ? 'pause:off' : 'pause:on') : 'paused';
    const armed = byId.get(armId).on;
    const paused = byId.get(pauseId).on;
    const arm = rampAction(armId, { label: armed ? (trifold ? 'Couper' : '✓ Armé') : 'Armer', active: armed });
    const pause = rampAction(pauseId, { label: paused ? 'Reprendre' : 'Pause', active: paused });
    if (trifold) {
        arm.disabled = !open || moving;
        pause.disabled = !armed;
    }
    controlRow.append(arm, pause);
    if (moving) {
        movementTimer = setTimeout(() => {
            state.textContent = settled;
            if (trifold) arm.disabled = !open;
        }, options.rampMotion.remainingMs);
    }
    const modes = node('div', 'choice-row');
    for (const key of trifold ? ['barre', 'gauche', 'droite'] : ['ligne', 'gauche', 'droite', 'double']) {
        const id = 'mode:' + key;
        const item = byId.get(id);
        if (!item) continue;
        const button = rampAction(id, { active: item.on, className: 'mode-button' });
        button.title = item.label;
        button.setAttribute('aria-label', item.label);
        button.replaceChildren(trifold ? window.CelkSignalArt.bedSignal(key) : window.CelkSignalArt.pattern(key));
        modes.append(button);
    }
    presets.append(controlRow, modes);
    grid.append(shutter, presets);

    const lights = section('Éclairage', 'ramp-lights', 'h3');
    const switches = node('div', 'stack light-controls');
    const segments = node('div', 'segment-row');
    for (const id of ['coins:off', 'coins:linked', 'coins:independent']) {
        const item = byId.get(id);
        if (item) segments.append(rampAction(id, { active: item.on, className: 'segment' }));
    }
    if (segments.childElementCount) switches.append(node('h4', '', 'Coins ambre'), segments);
    if (byId.has('serviceLights')) {
        const whites = node('div', 'setting');
        const on = byId.get('serviceLights').on;
        whites.append(node('h4', '', 'Feux blancs'), rampAction('serviceLights', {
            label: on ? 'Allumés' : 'Éteints', active: on,
        }));
        whites.lastElementChild.setAttribute('aria-label', 'Feux blancs · ' + (on ? 'allumés' : 'éteints'));
        switches.append(whites);
    }
    if (switches.childElementCount) {
        lights.append(switches);
        grid.append(lights);
    }
    container.append(grid);
}

function showAuxPanel(panel, container) {
    const def = panel.definition, pose = panel.pose;
    const byKey = new Map(panel.controls.map(item => [item.key, item]));
    const button = (key, properties = {}) => action(byKey.get(key), 'auxPanel', properties);
    const grid = node('div', 'ramp-grid trifold-grid aux-panel-grid');
    const shutter = section(def.label, 'stack shutter', 'h3');
    const row = node('div', 'shutter-control');
    const active = def.modes.find(mode => mode.id === pose.mode);
    const settled = pose.target ? 'Déployé' : 'Replié';
    const moving = pose.remainingMs > 0;
    const state = node('p','shutter-state',moving ? (pose.target ? 'Déploiement…' : 'Repli…') : settled);
    row.append(window.CelkSignalArt.panelDiagram(def,active,pose), state,
        button(pose.target ? 'close' : 'open', { className: 'primary' }));
    shutter.append(row);
    const presets = section('Signal','motifs','h3');
    const controls = node('div','section-heading');
    const arm = button(pose.armed ? 'signal:off' : 'signal:on',{active:pose.armed});
    const pause = button(pose.paused ? 'pause:off' : 'pause:on',{active:pose.paused});
    arm.disabled = !pose.target || moving;
    pause.disabled = !pose.armed;
    controls.append(arm,pause);
    if (moving) {
        const timer = setTimeout(() => {
            panelTimers.delete(timer);
            state.textContent = settled;
            arm.disabled = !pose.target;
        }, pose.remainingMs);
        panelTimers.add(timer);
    }
    const modes = node('div','choice-row');
    modes.style.gridTemplateColumns = 'repeat(' + def.modes.length + ',minmax(0,1fr))';
    for (const mode of def.modes) {
        const control = button('mode:' + mode.id,{active:mode.id === pose.mode, className:'mode-button'});
        control.title = mode.label;
        control.setAttribute('aria-label',mode.label);
        control.replaceChildren(window.CelkSignalArt.panelDiagram(def,mode), node('span','aux-mode-label',mode.label));
        modes.append(control);
    }
    presets.append(controls,modes);
    grid.append(shutter,presets);
    container.append(grid);
}

function showScenes(options, ramp) {
    const variants = section('Variantes de lumière', 'light-variants');
    const grid = node('div', options.choices.length ? 'choice-list named-choices' : 'choice-list');
    for (const item of options.choices) grid.append(action(item, 'scene', { active: item.id === options.selected }));
    for (let slot = options.choices.length; slot < 5; slot += 1) {
        const empty = node('button', 'empty-variant', '—');
        empty.type = 'button';
        empty.disabled = true;
        empty.setAttribute('aria-label', 'Emplacement libre');
        grid.append(empty);
    }
    variants.append(grid);
    if (typeof options.scenePlayback?.on === 'boolean') {
        const playing = options.scenePlayback.on;
        const control = action({ id: playing ? 'off' : 'on', label: playing ? 'Arrêter la scène' : 'Lire la scène' },
            'scenePlayback', { active: playing, className: 'playback-control' });
        variants.append(control);
    }
    if (!options.choices.length) {
        variants.append(node('p', 'detail empty-notice', 'Aucune variante de lumière dans ce montage.'));
    } else if (options.serviceScenes !== true && options.selected === '' && !options.choices.some(item => item.id === '')) {
        variants.append(node('p', 'detail scene-status', 'Séquence d’origine active.'));
    }
    choices.append(variants);
    if (!ramp && !options.auxPanels?.length && !options.projectors?.length) return;

    const auxiliaries = section('Auxiliaires', 'auxiliaries');
    if (ramp) showRamp(options, auxiliaries);
    for (const panel of options.auxPanels ?? []) showAuxPanel(panel, auxiliaries);
    if (options.projectors?.length) {
        const projectors = node('div', 'projector-grid');
        for (const head of options.projectors) {
            const card = section(head.label, 'stack projector', 'h3');
            const controls = node('div', 'projector-controls');
            const toggle = action(head, 'projector', { label: head.on ? 'Éteindre' : 'Allumer', active: head.on });
            toggle.setAttribute('aria-label', toggle.textContent + ' ' + head.label);
            controls.append(toggle);
            if (head.aimable) {
                const aim = action(head, 'projectorAim', { label: 'Viser', icon: 'target', className: 'aim-action', active: head.selected });
                aim.setAttribute('aria-label', 'Viser avec ' + head.label + ' au pavé numérique 4, 6, 8 et 2');
                controls.append(aim);
                const detail = node('div', 'detail aim-detail');
                detail.append(node('span', 'aim-angles', head.yaw + '° / ' + head.pitch + '°'));
                const keys = node('span', 'aim-keys');
                keys.setAttribute('aria-hidden', 'true');
                for (const [key, icon] of [['4', 'left'], ['6', 'right'], ['8', 'up'], ['2', 'down']]) {
                    const keycap = node('kbd', 'aim-key', key);
                    keycap.prepend(pictogram(icon));
                    keys.append(keycap);
                }
                detail.append(keys);
                card.append(detail);
            }
            card.append(controls);
            projectors.append(card);
        }
        auxiliaries.append(projectors);
    }
    choices.append(auxiliaries);
}

window.addEventListener('message', ({ data }) => {
    if (data?.type === 'close') {
        if (menu.contains(document.activeElement)) document.activeElement.blur();
        menu.hidden = true;
        session = pending = undefined;
        menu.removeAttribute('aria-busy');
        clearMotion();
        return;
    }
    if (data?.type !== 'open' || !Number.isInteger(data.session) || !Array.isArray(data.options?.choices)) return;
    const options = data.options;
    const fitting = options.pane === 'variants';
    const ramp = !fitting && options.rampControls?.some(item => item.id === 'open');
    const last = data.session === session ? document.activeElement : null;
    session = data.session;
    pending = undefined;
    menu.removeAttribute('aria-busy');
    clearMotion();
    choices.replaceChildren();
    menu.classList.toggle('mounts', fitting);
    menu.classList.toggle('lighting', !fitting);
    menu.classList.toggle('has-auxiliaries', !fitting && Boolean(ramp || options.auxPanels?.length || options.projectors?.length));
    document.querySelector('#key').textContent = fitting ? 'F6' : 'J';
    document.querySelector('#title').textContent = fitting ? 'Montages' :
        ramp ? (options.service === 'mecano' ? 'Remorqueur' : 'Rampe Police') : 'Commandes d’éclairage';
    const subtitle = document.querySelector('#subtitle');
    const model = typeof options.model === 'string' ? options.model.replace(/^./, c => c.toUpperCase()) : '';
    subtitle.textContent = fitting || ramp ? model : options.mountLabel ?? model;
    subtitle.hidden = !subtitle.textContent;
    announce(options.notice);
    if (fitting) showMounts(options.choices, options.selected);
    else showScenes(options, ramp);
    menu.hidden = false;
    if (!fitting) fitLighting();
    const buttons = [...choices.querySelectorAll('button:not(:disabled)')];
    const focus = last === close ? close : buttons.find(button =>
        button.dataset.action === last?.dataset.action && button.dataset.id === last?.dataset.id);
    const active = choices.querySelector('button[aria-pressed="true"]');
    (focus ?? active ?? buttons[0] ?? close).focus({ preventScroll: !fitting });
});

window.addEventListener('resize', fitLighting);
close.addEventListener('click', () => send('close'));
document.addEventListener('keydown', event => {
    if (menu.hidden) return;
    if (event.key === 'Escape') {
        event.preventDefault();
        send('close');
    } else if (event.key === 'Tab') {
        const buttons = [...menu.querySelectorAll('button:not(:disabled)')];
        const first = buttons[0], last = buttons.at(-1);
        if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
        }
    }
});
